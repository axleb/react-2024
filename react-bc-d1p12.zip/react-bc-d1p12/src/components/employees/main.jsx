import React, {Component} from "react";
//
class Main extends Component{
  constructor(props){
    super(props);
    this.state = {
      allEmployees: []
    };
  };
  componentDidMount(){
    fetch("http://localhost:5100/employees")
    .then( data => data.json() )
    .then(resolvedData => {
      this.setState({allEmployees:resolvedData});
      //console.log(this.state.allEmployees[0]);
    });
  };

  render(){
    return (
      <main>
        <h2>Employee List</h2>
        {
          this.state.allEmployees.map( (employee, i) =>
            (
              <div key={i}>
                { employee.username } {employee.password}
              </div>
            )
          )
        }
      </main>
    )
  };
};
//
export default Main;
