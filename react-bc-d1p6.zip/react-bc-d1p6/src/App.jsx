
import './styles.css'
import {BrowserRouter, Route, Routes} from 'react-router-dom';
import Header from './components/header';
import Container from './components/container';
import Footer from './components/footer';
//
function App() {
  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route path='/' element={<Header />} />
          <Route path='/container' element={<Container />} />
        </Routes>
      </BrowserRouter>
    </>
  )
}
//
export default App
